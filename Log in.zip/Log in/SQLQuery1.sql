create database goodsReceived
create table goods(
	ID varchar(10),
	nameG varchar(100),
	dateRe date,
	supplier varchar(10),
	price int,
	quantity int,
	brand varchar(20)
)

create table delivery(
	deliveryID varchar(10),
	deliveryDate date,
	agentID varchar(10),
	productID varchar(10),
	status varchar(20),
	paymentMethods varchar(20),
	paymentStatus varchar(10),
	quantity int,
	price int
)
insert into goods values ('G01','Iphone 13 Promax' ,'2023/04/17','Company A',3000000,2, 'Apple')
insert into goods values ('G02','Iphone 14 Promax' , '2023/04/17','Company B',4000000,2,'Apple')
insert into goods values ('G03', 'Iphone 13 Pro' ,'2023/04/17','Company C',5000000,2,'Apple')
select * from goods
insert into delivery values ('D01','2023/04/23','E01','G01','Not transfer','By Cash','Complete',10,2000000)
select * from delivery

alter table delivery
alter column paymentMethods varchar(30);

alter table delivery
alter column paymentStatus varchar(50);
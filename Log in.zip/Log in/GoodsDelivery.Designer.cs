﻿namespace Log_in
{
    partial class GoodsDelivery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grb1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.fdsà = new System.Windows.Forms.Label();
            this.dtp = new System.Windows.Forms.DateTimePicker();
            this.txtProduct = new System.Windows.Forms.TextBox();
            this.txtAgent = new System.Windows.Forms.TextBox();
            this.txtDeli = new System.Windows.Forms.TextBox();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtQuality = new System.Windows.Forms.TextBox();
            this.txtgoods = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grb2 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnTrans = new System.Windows.Forms.Button();
            this.grd = new System.Windows.Forms.DataGridView();
            this.grb1.SuspendLayout();
            this.grb2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).BeginInit();
            this.SuspendLayout();
            // 
            // grb1
            // 
            this.grb1.Controls.Add(this.comboBox1);
            this.grb1.Controls.Add(this.fdsà);
            this.grb1.Controls.Add(this.dtp);
            this.grb1.Controls.Add(this.txtProduct);
            this.grb1.Controls.Add(this.txtAgent);
            this.grb1.Controls.Add(this.txtDeli);
            this.grb1.Controls.Add(this.txtPayment);
            this.grb1.Controls.Add(this.txtPrice);
            this.grb1.Controls.Add(this.txtQuality);
            this.grb1.Controls.Add(this.txtgoods);
            this.grb1.Controls.Add(this.label4);
            this.grb1.Controls.Add(this.label3);
            this.grb1.Controls.Add(this.label2);
            this.grb1.Controls.Add(this.label8);
            this.grb1.Controls.Add(this.label7);
            this.grb1.Controls.Add(this.label6);
            this.grb1.Controls.Add(this.label5);
            this.grb1.Controls.Add(this.label1);
            this.grb1.Location = new System.Drawing.Point(5, 12);
            this.grb1.Name = "grb1";
            this.grb1.Size = new System.Drawing.Size(783, 216);
            this.grb1.TabIndex = 1;
            this.grb1.TabStop = false;
            this.grb1.Text = "Information";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "By Cash",
            "Banking",
            "Momo"});
            this.comboBox1.Location = new System.Drawing.Point(515, 65);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(259, 24);
            this.comboBox1.TabIndex = 6;
            // 
            // fdsà
            // 
            this.fdsà.AutoSize = true;
            this.fdsà.Location = new System.Drawing.Point(399, 66);
            this.fdsà.Name = "fdsà";
            this.fdsà.Size = new System.Drawing.Size(111, 16);
            this.fdsà.TabIndex = 2;
            this.fdsà.Text = "paymentMethods";
            // 
            // dtp
            // 
            this.dtp.Location = new System.Drawing.Point(96, 60);
            this.dtp.Name = "dtp";
            this.dtp.Size = new System.Drawing.Size(284, 22);
            this.dtp.TabIndex = 2;
            // 
            // txtProduct
            // 
            this.txtProduct.Location = new System.Drawing.Point(95, 147);
            this.txtProduct.Name = "txtProduct";
            this.txtProduct.Size = new System.Drawing.Size(285, 22);
            this.txtProduct.TabIndex = 4;
            // 
            // txtAgent
            // 
            this.txtAgent.Location = new System.Drawing.Point(95, 103);
            this.txtAgent.Name = "txtAgent";
            this.txtAgent.Size = new System.Drawing.Size(285, 22);
            this.txtAgent.TabIndex = 3;
            // 
            // txtDeli
            // 
            this.txtDeli.Location = new System.Drawing.Point(95, 23);
            this.txtDeli.Name = "txtDeli";
            this.txtDeli.Size = new System.Drawing.Size(285, 22);
            this.txtDeli.TabIndex = 1;
            // 
            // txtPayment
            // 
            this.txtPayment.Location = new System.Drawing.Point(515, 109);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(262, 22);
            this.txtPayment.TabIndex = 7;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(329, 180);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(136, 22);
            this.txtPrice.TabIndex = 9;
            // 
            // txtQuality
            // 
            this.txtQuality.Location = new System.Drawing.Point(515, 147);
            this.txtQuality.Name = "txtQuality";
            this.txtQuality.Size = new System.Drawing.Size(260, 22);
            this.txtQuality.TabIndex = 8;
            // 
            // txtgoods
            // 
            this.txtgoods.Location = new System.Drawing.Point(515, 26);
            this.txtgoods.Name = "txtgoods";
            this.txtgoods.Size = new System.Drawing.Size(261, 22);
            this.txtgoods.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "agentID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "productID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "deliveryDate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(266, 186);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(399, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(399, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "paymentStatus";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(399, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "goodsStatus";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "deliveryID";
            // 
            // grb2
            // 
            this.grb2.Controls.Add(this.btnDelete);
            this.grb2.Controls.Add(this.btnPrint);
            this.grb2.Controls.Add(this.btnSave);
            this.grb2.Controls.Add(this.btnUpdate);
            this.grb2.Controls.Add(this.btnAdd);
            this.grb2.Controls.Add(this.btnTrans);
            this.grb2.Location = new System.Drawing.Point(3, 234);
            this.grb2.Name = "grb2";
            this.grb2.Size = new System.Drawing.Size(785, 41);
            this.grb2.TabIndex = 10;
            this.grb2.TabStop = false;
            this.grb2.Text = "Function";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(181, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 131;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(632, 12);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 130;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(524, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(407, 12);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(77, 12);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnTrans
            // 
            this.btnTrans.Location = new System.Drawing.Point(292, 12);
            this.btnTrans.Name = "btnTrans";
            this.btnTrans.Size = new System.Drawing.Size(75, 23);
            this.btnTrans.TabIndex = 10;
            this.btnTrans.Text = "Transfer";
            this.btnTrans.UseVisualStyleBackColor = true;
            this.btnTrans.Click += new System.EventHandler(this.btnTrans_Click);
            // 
            // grd
            // 
            this.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd.Location = new System.Drawing.Point(3, 281);
            this.grd.Name = "grd";
            this.grd.RowHeadersWidth = 51;
            this.grd.RowTemplate.Height = 24;
            this.grd.Size = new System.Drawing.Size(785, 169);
            this.grd.TabIndex = 11;
            this.grd.Click += new System.EventHandler(this.grd_Click);
            // 
            // GoodsDelivery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grd);
            this.Controls.Add(this.grb2);
            this.Controls.Add(this.grb1);
            this.Name = "GoodsDelivery";
            this.Text = "GoodsDelivery";
            this.Load += new System.EventHandler(this.GoodsDelivery_Load);
            this.grb1.ResumeLayout(false);
            this.grb1.PerformLayout();
            this.grb2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grb1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label fdsà;
        private System.Windows.Forms.DateTimePicker dtp;
        private System.Windows.Forms.TextBox txtProduct;
        private System.Windows.Forms.TextBox txtAgent;
        private System.Windows.Forms.TextBox txtDeli;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtQuality;
        private System.Windows.Forms.TextBox txtgoods;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grb2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnTrans;
        private System.Windows.Forms.DataGridView grd;
    }
}